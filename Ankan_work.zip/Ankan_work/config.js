loadConfig({

    "Page Title": "Apparent Banner Review Site",

    "Client Name": "Portfolio",

    "Job Number": "Ankan Ghosh ",

    "Job Description": "Interactive Developer",

});